document.addEventListener('DOMContentLoaded', function() {
    const cartIcon = document.querySelector('.fa-cart-shopping');
    const cartCountElement = document.getElementById('increase');

    // Function to update cart count
    function updateCartCount() {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        cartCountElement.innerText = cart.length;
    }

    // Clear cart on page load
    localStorage.removeItem('cart');
    updateCartCount();

    cartIcon.closest('a').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent the link from navigating directly
        window.location.href = 'cart.html'; // Use JavaScript to navigate
    });
});
