document.addEventListener('DOMContentLoaded', function() {
    const addToCartButtons = document.querySelectorAll('.food-items button');
    const cartIcon = document.querySelector('.fa-cart-shopping');
    const cartCountElement = document.getElementById('increase');

    // Function to update cart count
    function updateCartCount() {
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        cartCountElement.innerText = cart.length;
    }

    // Clear cart on page load
    localStorage.removeItem('cart');
    updateCartCount();

    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productName = this.closest('.food-items').querySelector('h5').textContent;
            let cart = JSON.parse(localStorage.getItem('cart')) || [];
            cart.push(productName);
            localStorage.setItem('cart', JSON.stringify(cart));

            // Update Cart Count
            updateCartCount();
        });
    });

    cartIcon.closest('a').addEventListener('click', function(e) {
        e.preventDefault(); // Prevent the link from navigating directly
        // window.location.href = 'cart.html'; // Use JavaScript to navigate
    });
});
