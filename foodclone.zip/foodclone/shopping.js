let openShopping = document.querySelector('.shopping');
let closeShopping = document.querySelector('.closeShopping');
let list = document.querySelector('.list');
let listCard = document.querySelector('.listCard');
let body = document.querySelector('body');
let total = document.querySelector('.total');
let quantity = document.querySelector('.quantity');

openShopping.addEventListener('click', () => {
    body.classList.add('active');
});

closeShopping.addEventListener('click', () => {
    body.classList.remove('active');
});

let products = [
    {
        id: 1,
        name: 'PRODUCT NAME 1',
        image: 'foodclone\\1.jpg', // Corrected with double backslashes
        price: 12000
    },
    {
        id: 2,
        name: 'PRODUCT NAME 2',
        image: 'foodclone\\2.jpg', // Corrected with double backslashes
        price: 15000
    },
    {
        id: 3,
        name: 'Product Name 3',
        image: 'foodclone\\3.jpg', // Corrected with double backslashes
        price: 15000
    },
    {
        id: 4,
        name: 'PRODUCT NAME 2',
        image: 'foodclone\\4.jpg', // Corrected with double backslashes
        price: 15000
    },
    {
        id: 5,
        name: 'PRODUCT NAME 2',
        image: 'foodclone\\5.jpg', // Corrected with double backslashes
        price: 15000
    },
    {
        id: 6,
        name: 'PRODUCT NAME 2',
        image: 'foodclone\\6.jpg', // Corrected with double backslashes
        price: 15000
    }
];

let listCards = [];

function initApp() {
    products.forEach((value, key) => {
        let newDiv = document.createElement('div');
        newDiv.classList.add('item');
        newDiv.innerHTML = `
            <img src="image/${value.image}" />
            <div class="title">${value.name}</div> 
            <div class="price">${value.price.toLocaleString()}</div>
            <button onclick="addToCard(${key})">Add To Card</button> <!-- Added quotation mark -->
        `;
        list.appendChild(newDiv);
    });
}

initApp();
function addToCard(key){
    if(listCards[key]==null){
        listCards[key]=products[key];
        listCards[key].quantity=1;
    }
    reloadCard();
}
function reloadCard() {
    listCard.innerHTML = '';
    let count = 0;
    let totalPrice = 0;
    listCards.forEach((value, key) => {
        if (value != null) {
            let newDiv = document.createElement('li');
            newDiv.innerHTML = `
                <div><img src="image/${value.image}" /></div>
                <div>${value.name}</div> 
                <div>${value.price.toLocaleString()}</div>
                <div>${value.quantity}</div>
                <div>
                    <button onclick="changeQuantity(${key}, ${value.quantity - 1})">-</button>
                    <div class="count">${value.quantity}</div>
                    <button onclick="changeQuantity(${key}, ${value.quantity + 1})">+</button>
                </div>
            `;
            listCard.appendChild(newDiv);
            totalPrice += value.price * value.quantity;
            count += value.quantity;
        }
    });

    total.textContent = totalPrice.toLocaleString();
    quantity.textContent = count;
}